package gameEntities;

import java.applet.AudioClip;
import java.awt.image.BufferedImage;

import javax.swing.ImageIcon;

public class Diamond extends GameObject {

	BufferedImage image;

	AudioClip audio;
	
	public Diamond(){	
	
	}

	@Override
	public ImageIcon getImageIcon() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
